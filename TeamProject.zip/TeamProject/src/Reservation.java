import java.awt.*;

import java.awt.event.*;

import javax.swing.*;

import javax.swing.border.Border;

import java.util.*;

import java.io.*;

class RoomandReservationPanel extends JPanel // BuildingFrame ���� �� Ŭ���� �迭�� �����ϰ� ���Ͽ��� �Է¹ޱ�

{

	public RoomandReservationPanel(String buildingfilename,String roomnumber, String cur_pos_state)

	{

		setLayout(new FlowLayout());

		Room room = new Room(roomnumber);

		ReservationClass reserve = new ReservationClass(buildingfilename,roomnumber,cur_pos_state);

		add(room);

		add(reserve);

	}

}



class ReservationClass extends JButton implements ActionListener

{

	String buildingfilename;

	String roomnumber;

	String totalnumber;



	public ReservationClass(String buildingfilename,String roomnumber, String current_position_state)

	{

		super(current_position_state);

		addActionListener(this);

		this.buildingfilename=buildingfilename;

		this.roomnumber=roomnumber;

	}



	@Override

	public void actionPerformed(ActionEvent e) //actionListener - ReservePopUp �����ֱ� 

	{

		// TODO Auto-generated method stub

		ReservePopUp reservepopup = new ReservePopUp();

		reservepopup.setVisible(true);

	}



	private class ReservePopUp extends JFrame implements ActionListener

	{

		private int Reserve_All_Num=0;



		public ReservePopUp()

		{

			setSize(400,200);

			getContentPane().setBackground(Color.yellow);

			setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);

	        addWindowListener(new CheckOnExit(this));



	        setLayout(new BorderLayout());



	        JLabel Title = new JLabel("���డ��");

	        add(Title, BorderLayout.NORTH);



	        JPanel butpane=new JPanel();

	        butpane.setLayout(new FlowLayout());



	        JButton All=new JButton("��°��");

	        JButton One=new JButton("����");



	        All.addActionListener(this);

	        One.addActionListener(this);



	        butpane.add(All);

	        butpane.add(One);

	         // ��ư ���̽� Insets Ŭ������ ����

	        add(butpane, BorderLayout.SOUTH);

		}





		public void actionPerformed(ActionEvent e) 

	    {

	       String message=e.getActionCommand();

	       Scanner inputstream=null;



	       if(message.equals("��°��"))

           {

	    	  try

	    	  {

	    		  inputstream = new Scanner(new FileInputStream(buildingfilename));

	    		  while(inputstream.hasNextLine())

	    		  {

	    			  String line= inputstream.nextLine();

	    			  StringTokenizer ptoken = new StringTokenizer(line);

	    			  if(ptoken.nextToken().equals(roomnumber))

	    			  {

	    				  totalnumber=ptoken.nextToken();

	    				  String curnum=ptoken.nextToken();

	    				  if(curnum.equals("0"))

	    				  {

	    					  ReserveALL Allwindow = new ReserveALL();

	    			          Allwindow.setVisible(true);

	    				  }

	    				  else 

	    				  {

	    					  CheckRegister gui=new CheckRegister("     ��°�� ������ �Ұ��մϴ�.    ");

	    					  gui.setVisible(true);

	    				  }

	    				  break;

	    			  }

	    		  }

	    		  inputstream.close();

	    	  }

	    	  catch(FileNotFoundException x)

	    	  {

	    		  System.out.println("No "+ buildingfilename);

	    	  }

	    	}

	       else if(message.contentEquals("����"))

	       {

	    	   try

		       {

		    	   inputstream = new Scanner(new FileInputStream(buildingfilename));

		    	   while(inputstream.hasNextLine())

		    	   {

		    	       String line= inputstream.nextLine();

		    		   StringTokenizer ptoken = new StringTokenizer(line);

		    		   if(ptoken.nextToken().equals(roomnumber))

		    		   {

		    			  String total=ptoken.nextToken();

		    			  String curnum=ptoken.nextToken();

		    			  if(curnum.equals(total))

		    			  {

		    				 CheckRegister gui=new CheckRegister("     ��°�� ������ �Ұ��մϴ�.    ");

		    			     gui.setVisible(true);

		    			  }

		    			  else 

		    			  {

		    				 ReserveOne Onewindow = new ReserveOne();

		    			     Onewindow.setVisible(true);

		    			  }



		    			  break;

		    			}

		    		 }

		    	   inputstream.close();

		       }

		       catch(FileNotFoundException x)

		       {

		    	System.out.println("No "+ buildingfilename);

		       }

           }  





	     }



		private class ReserveALL extends JFrame

	    {

	       public static final int ReserveAll_width = 350;

	       public static final int ReserveAll_height = 650;

	       JScrollPane scroll;



	       public ReserveALL()

	       {

	          setSize(ReserveAll_width, ReserveAll_height);

              setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);

              addWindowListener(new CheckOnExit(this));

              setLayout(new FlowLayout());



              JLabel title =new JLabel("          ���� ����             ");

              add(title, BorderLayout.NORTH);



              JLabel cf=new JLabel("���ǽ� ������ 1/4 �̻� �ο��� ���� ����");

              add(cf, BorderLayout.AFTER_LAST_LINE);

              JLabel cf1=new JLabel("ID                    �й�                        ���"); 

              add(cf1, BorderLayout.AFTER_LAST_LINE);



	          JPanel big = new JPanel();

	          big.setSize(250, 300);

	          big.setLayout(new GridLayout(20,1));



	          GridBagLayout gridbag = new GridBagLayout();

	          big.setLayout(gridbag);

	          GridBagConstraints constraint = new GridBagConstraints();

	          constraint.fill=GridBagConstraints.BOTH;

	          constraint.weightx = 1.0;

	          constraint.gridwidth = GridBagConstraints.REMAINDER;

	          constraint.gridheight = 1;

	          constraint.weighty = 1; 



	          InputPanel[] input = new InputPanel[70];



	          for(int i=0; i<input.length; i++) {

	            input[i]=new InputPanel(Integer.toString(i+1));

	            gridbag.setConstraints(input[i], constraint);

                big.add(input[i]);   

              }





	            scroll = new JScrollPane(big,JScrollPane.VERTICAL_SCROLLBAR_ALWAYS, JScrollPane.HORIZONTAL_SCROLLBAR_ALWAYS);

	            scroll.setPreferredSize(new Dimension(300, 500));

	            add(scroll);



	            RealDoneRegister window = new  RealDoneRegister();

	            add(window);

	        }

	    } //ReserveAll



		private class ReserveOne extends JFrame

	    {

	    	public static final int ReserveOnePopUp_width = 300;

	        public static final int ReserveOnePopUp_height = 150;



	        public ReserveOne()

	        {

	           setSize(ReserveOnePopUp_width, ReserveOnePopUp_height);

	           setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);

	           addWindowListener(new CheckOnExit(this));

	           setLayout(new FlowLayout());

	           JLabel title =new JLabel("          ���� ����             ");

	           add(title, BorderLayout.NORTH);



	           JLabel cf1=new JLabel("ID                    �й�                        ���");

	           add(cf1, BorderLayout.AFTER_LAST_LINE);



	           InputPanel info = new InputPanel("None");

	           add(info);

	         }

	     } //ReserveOne



		private class InputPanel extends JPanel implements ActionListener

	    {

	        JTextField id;

	        JTextField num_id;

	        JButton register;

	        int how_many=1;

	        boolean Reserve_one;

	        //public static final int NUMBER_OF_CHAR=6;

            public InputPanel(String idx)

            {         

	            setLayout(new FlowLayout());

	            JLabel idxnum;



	            if(!idx.contentEquals("None"))

	            {

	            	idxnum = new JLabel(idx);

	            	add(idxnum);

	            	Reserve_one=false;

	            }

	            else

	            	Reserve_one=true;





	            id=new JTextField("Enter ID", 6);

	            num_id = new JTextField("Enter �й�", 10);

	            register = new JButton("���");

	            register.addActionListener(this);



	            add(id);

	            add(num_id);

	            add(register);   

	         }



             public int getHowMany()

             {

            	 return  how_many;

             }

	         public void actionPerformed(ActionEvent e)

	         {

	            //ȸ������ ����//

	        	RegisterDone checkRegister = new RegisterDone("     ����� �Ϸ� �Ͻðڽ��ϱ�?     ", this);

	        	checkRegister.setVisible(true);



	         }



	         public boolean FindRegister()

	         {

	        	 //id, ��й�ȣ , �й�, �̸�

	        	 Scanner inputStream=null;

	        	 String line;

	        	 String Id;

	        	 String IdNum;

	        	 try

	        	 {

	        		 inputStream=new Scanner(new FileInputStream("ȸ������.txt"));	

	        	 }



	        	 catch(FileNotFoundException e)

	        	 {

	        		 // â���� �ٲٱ� 

	        		 System.out.println("Problem opening Information. Fatal Error");

	                 System.exit(0);

	        	 }	



	        	 while(inputStream.hasNextLine())

	    		 {

	    			 line=inputStream.nextLine();

	    			 StringTokenizer ptoken= new StringTokenizer(line, "/");
	    			 String name = ptoken.nextToken();

	    			 Id=ptoken.nextToken();

	    			 if(id.getText().equals(Id))

	    			 {

	    				 Id=ptoken.nextToken(); //��й�ȣ �ѱ��

	    				 IdNum=ptoken.nextToken(); 

	    				 if(num_id.getText().equals(IdNum))

	    					 return true; 

	    			} 			

	    		 }	 

	        	 inputStream.close();

	        	 return false;

	          }



	         private class RegisterDone extends JFrame implements ActionListener

			  {

			      public static final int PopUp_width = 300;

			      public static final int PopUp_height = 100;

			      InputPanel panel;

			      int how_many;

			      public RegisterDone(String str, InputPanel pane)

			      {

			         setSize(PopUp_width, PopUp_height);

			         setLayout(new BorderLayout());

			         panel=pane;

			         how_many=panel.getHowMany();

			         JLabel message = new JLabel(str);

			         add(message, BorderLayout.CENTER);

			         JPanel yesno = new JPanel();

			         yesno.setLayout(new FlowLayout());

			         JButton yes = new JButton("��");

			         JButton no = new JButton("�ƴϿ�");

			         yes.addActionListener(this);

			         no.addActionListener(this);

			         yesno.add(yes);

			         yesno.add(no);

			         add(yesno, BorderLayout.SOUTH);

			      }





			      public void actionPerformed(ActionEvent e)

			       {

			    	   String message = e.getActionCommand();

			    	   CheckRegister gui; 

			    	   ReplaceFile replacefile;

			    	   if(message.equals("��"))

			    	   {

			    		   if(FindRegister()==true)

			    		   {// ���� ȸ������ ��ġ�ϰų� �ռ� �ߺ� ��û ��������

			    			   if(Reserve_one)

			    				   replacefile= new ReplaceFile(buildingfilename, roomnumber, how_many);

			    			   else

			    				   Reserve_All_Num++;

			    			   panel.setBackground(Color.green);

			    			   gui = new CheckRegister("        ����� �Ϸ�Ǿ����ϴ�.         ");

			    			   gui.setVisible(true);





			    		   }



				           else if(FindRegister()==false)

				           {

				               panel.setBackground(Color.red);

				               gui= new CheckRegister("       Ȯ�ε��� ���� ������Դϴ�.  �ٽ� �Է��� �ּ���.     ");

				               gui.setVisible(true);

				           }

			    		   dispose();

			    	   }



			    	   else if(message.equals("�ƴϿ�"))

			    		   dispose();





	   	           } 

			   } //RegisterDone

	      } // InputPanel  



			private class RealDoneRegister extends JButton implements ActionListener

			{

			   public RealDoneRegister()

			   {

				   super("��� �Ϸ�");

				   setBackground(Color.red);

				   addActionListener(this);

			   }



			   public void actionPerformed(ActionEvent e) 

			   {

				   CheckRealRegisterDone window = new CheckRealRegisterDone("        ����� �Ϸ��Ͻðڽ��ϱ�?      ");

				   window.setVisible(true);

			   }



			   private class CheckRealRegisterDone extends JFrame implements ActionListener

			   {

				   public CheckRealRegisterDone(String str)

				   {

					   setSize(300,100);

					   setLayout(new BorderLayout());



				       JLabel message = new JLabel(str);

				       add(message, BorderLayout.CENTER);

				       JPanel yesno = new JPanel();

				       yesno.setLayout(new FlowLayout());

				       JButton yes = new JButton("��");

				       JButton no = new JButton("�ƴϿ�");

				       yes.addActionListener(this);

				       no.addActionListener(this);

				       yesno.add(yes);

				       yesno.add(no);

				       add(yesno, BorderLayout.SOUTH);



				   }



				@Override

				  public void actionPerformed(ActionEvent e)

				  {

					// TODO Auto-generated method stub

					String message=e.getActionCommand();

					 if(message.equals("��"))

			    	   {

			    		   if(Integer.parseInt(totalnumber)/4 <= Reserve_All_Num)

			    		   {

			    			   ReplaceFile replace = new ReplaceFile(buildingfilename, roomnumber, Reserve_All_Num);

			    			   CheckRegister gui = new CheckRegister("      ����� �Ϸ�Ǿ����ϴ�.       ");

			    			   gui.setVisible(true);

			    		   }

			    		   else if(Integer.parseInt(totalnumber)/4 > Reserve_All_Num)

			    		   {

			    			   CheckRegister gui = new CheckRegister("      ���ǽ� ������ 1/4�� ���� ���մϴ�.      ");

			    			   gui.setVisible(true);

			    		   }

			    		   else if(Integer.parseInt(totalnumber) < Reserve_All_Num)

			    		   {

			    			   CheckRegister gui = new CheckRegister("      ���ǽ� ���� �ʰ��� ������ �� �����ϴ�.      ");

			    			   gui.setVisible(true);

			    		   }

			    		  dispose();

			    	   }





			    	 else if(message.equals("�ƴϿ�"))

			    		 dispose();



					 //ȸ�� �ߺ� üũ ��� �־����

			      }

			   }

		   }

	}//ReservePopUp 



}



class ReplaceFile

{

	String originfilename;

	String replacefilename;

	String roomnumber;

	String room;

	int how_many_register;

	String totalnum;



	public ReplaceFile(String filename, String roomnumber, int how_many_register) // ������ü�� .txt �޾Ƽ���

	{

		originfilename=filename;

		replacefilename="replace"+ filename;

		this.roomnumber=roomnumber;

		this.how_many_register=how_many_register;

		try {

			replace();

		}



		catch(IOException e)

		{

			System.out.println("Error on deleting file");

		}

	}



	public void replace() throws IOException

	{

		BufferedReader inputbuffer = null;

		BufferedWriter outputbuffer = null;

		String cur_num;

		String cur_num_plus;



		try

		{

			inputbuffer=new BufferedReader(new FileReader(originfilename));

			outputbuffer = new BufferedWriter(new FileWriter(replacefilename));

			String line;

			while((line =inputbuffer.readLine())!=null)

			{

				StringTokenizer ptoken = new StringTokenizer(line);
				
				room =ptoken.nextToken();

				//System.out.println(line);

				//System.out.println(room);

				if(room.equals(roomnumber))

				{

					totalnum=ptoken.nextToken();

					cur_num = ptoken.nextToken();

					cur_num_plus = Integer.toString(Integer.parseInt(cur_num)+how_many_register);

					line=room+" "+totalnum+" "+cur_num_plus;

					//System.out.println(how_many_register);

				}

				outputbuffer.write(line+"\r\n");

			}

		}

		catch(Exception e)

		{

			System.out.println("No" + originfilename + "replacing file");

		}

		finally

		{

			try 

			{

				if(inputbuffer!=null)

					inputbuffer.close();

			}

			catch(IOException e)

			{

				System.out.println("Error replacing file");

			}



			try 

			{

				if(outputbuffer!=null)

					outputbuffer.close();

			}

			catch(IOException e)

			{

				System.out.println("Error replacing file");

			}
			
			File old = new File(originfilename);
			if(!old.delete())
				System.out.println("no delete");

			File replace = new File(replacefilename);

			replace.renameTo(old);


		}



		
	}

}



class CheckRegister extends JFrame

{

	public CheckRegister(String str)

	{

		setSize(300,100);

		setLayout(new BorderLayout());



        JLabel message = new JLabel(str);

        add(message, BorderLayout.CENTER);

	}

}



class Room extends JButton //���� �� ȣ�� ��ư 

{

	public Room(String roomnum)

	{

		setText(roomnum);

	}

}





class CheckOnExit extends WindowAdapter

{

	JFrame frame;

	public CheckOnExit(JFrame frame)

	{

		this.frame=frame;

    }



	public void windowClosing(WindowEvent e)

    {

		ComfirmWindow checker = new ComfirmWindow(frame);

    	checker.setVisible(true);

    }

}



class ComfirmWindow extends JFrame implements ActionListener

{

	   JFrame frame;

	   public ComfirmWindow(JFrame frame)

	   {

		   setSize(300,130);

		   setLayout(new FlowLayout());

		   JLabel confirm = new JLabel("     â�� �����ðڽ��ϱ�?      ");

		   add(confirm);



		   JPanel pane = new JPanel();

		   pane.setLayout(new FlowLayout());

		   JButton yes =new JButton("��");

		   JButton no = new JButton("�ƴϿ�");

		   yes.addActionListener(this);

		   no.addActionListener(this);



		   pane.add(yes);

		   pane.add(no);

		   add(pane);



		   this.frame=frame;

	   }



	@Override

	    public void actionPerformed(ActionEvent e) {

		// TODO Auto-generated method stub

			String message = e.getActionCommand();



			if(message.equals("��")) {

				dispose();

				frame.dispose();

			}

			else if(message.equals("�ƴϿ�"))

				dispose();

	   }

}